
def main():
    st = ""
    x, y = 12, 40
    if (x < y):
        st = "x is less than y"
    elif (x == y):
        st = "x is equal to y"
    else:
        st = "x is greater than y"

    print (st)

#print(st)
#    st2 = "x is greater than y"  if (x > y) elif (x == y) "x is equal to y" else "x is less than y"
#print(st)

if __name__ == "__main__":
    main()